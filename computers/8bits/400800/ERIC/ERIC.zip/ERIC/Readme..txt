This ZIP file contains all of the known Atari "E.R.I.C." Electronic Retail Information Center diskettes that were used to develop the software to allow the Atari 800 to communicate with the Pioneer laserdisc player to run ERIC.

Included are bootable disks, disks with source code and completed compiled code not just for ERIC but also for ERIK II the 1200XL version and code for playing Dragons Lair and Space Ace with the Atari 800.

Please keep all of these files together if you share and post them so that people can examine and use all of the code that has been recovered.

Thanks,

Curt Vendel
The Atari Museum
www.atarimuseum.com

