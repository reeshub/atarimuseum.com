#include <stdio.h>
int	bufcntr;
char	errflag;

main()
{

	char dbyte;

	printf("hit return to go on \n");
	getchar();

	init_if();
	printf("%2x %4x\n", errflag, bufcntr);

	while (errflag == 0)
	{
		while (bufcntr > 0)
		{
			dbyte = get_byte();
			if (dbyte == 176)
				errflag = 7;
/*			printf("%2x %4x\n", dbyte, bufcntr);  */
			out_byte(dbyte);
		}
	}
	printf("done \n");
	printf("%2x\n", errflag);
	un_init();
	exit();
}
