

/*-----------------------------------------------------------------------------
 * September 1983, Claudia Rudolph
 *
 *
 *-----------------------------------------------------------------------------
 */

#include <stdio.h>
#include <maestro.h>

main()
{
	int c;			/* Unbuffered input (and loop counter). */

	initport();		/* Set up i/o port locations.		*/

	for (;;) {
		putbar(TOP);	/* Clears screen.			*/
		printf("\t\t\t     Maestro v1.4 ");
		putright();
/*		putbar(BOT);
		printf("\t\b\b");
		putchar(TOPLEFT);
		for(c= 0; c < 64; c += 1) putchar(HORIZON);
		printf("%c\n\t\b\b%c",TOPRIGHT,VERTICAL);
*/
		putbar(MID);

		printf("  ");
		putright();
		printf(" Type:     'i'  to list the sound library and");
		putright();
		printf("                to add instruments to the orchestra,");
		putright();
		putright();
		printf("           'p'  to list the orchestra and             ");
		putright();
		printf("                to re-assign the players' instruments,");
		putright();
		putright();
		printf("           'm'  to play a song,                    ");
		putright();
		putright();
		printf("           'c'  to interface with the Chroma keyboard,");
		putright();
		putright();
		printf("           'b'  to pre-process .TAB files to binary,");
		putright();
		putright();
		printf("           'r'  to reset for re-allocation of the   ");
		putright();
		printf("                orchestra and players,              ");
		putright();
		putright();
		printf("           'a'  to alter an instrument file,        ");
		putright();
		putright();
		printf("           ESC  to quit.");
		putright();
		putbar(BOT);
		c = getch();
		if (c == 'i') dirtab();
		if (c == 'p') players();
		if (c == 'm') mbox();
		if (c == 'c') keyboard();
		if (c == 'b') pre_pro();
		if (c == 'r') reset();
		if (c == 'a') poker();
		if (c == ESC) {
			cursor(23,1);
			printf("\nAre you sure?");
			printf("  ( 'y' / anything )            \n");
			if (((c = getch()) == 'y') || (c == 'Y')) {
				cursor(24,1);
				printf("Good bye!                          ");
				exit(0);
			}
		}
		CLEAR;
		cursor(0,6);
	}
}
putbar(which)	/* Prints bars which are 67 characters long */
int which;
{
	int i;
	switch (which) {
	case TOP:
		CLEAR;
		cursor(0,6);
		printf("\t\b\b");
		putchar(TOPLEFT);
		for(i= 0; i < 64; i += 1) putchar(HORIZON);
		printf("%c\n\t\b\b%c",TOPRIGHT,VERTICAL);
		return;
	case MID:
		putchar('\b');
		putchar(MIDLEFT);
		for(i= 0; i < 64; i += 1) putchar(HORIZON);
		printf("%c\n\t\b\b%c",MIDRIGHT,VERTICAL);
		return;
	case BOT:
		putchar('\b');
		putchar(BOTLEFT);
		for(i= 0; i < 64; i += 1) putchar(HORIZON);
		putchar(BOTRIGHT);
		putchar('\n');
		return;
	}
}

putright()
{
	int line,col;

	curs_loc(&line,&col);
	cursor(line,72);
	printf("%c\n\t\b\b%c",VERTICAL,VERTICAL);
}