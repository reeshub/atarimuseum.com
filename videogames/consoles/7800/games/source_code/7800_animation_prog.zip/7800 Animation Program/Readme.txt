This program was developed by the Super Stunt Cycle (later renamed Motophyscho) programmer, it runs on an Atari ST Computer system, you will need to either run it natively on a real Atari ST or through an Atari ST emulator such as STeem.


Curt Vendel
The Atari Museum
www.atarimuseum.com



