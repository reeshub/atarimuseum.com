/*
cent2 outputs a file to the centronics port
The leading zero's are ignored
16/7/90

*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<bios.h>
#include	<conio.h>

main (int argc, char *argv[])

{
	int n,ch;
	char shch;
	FILE *infile,*outfile;
	unsigned char c;

	if (argc != 2)
	{
		printf ("parameter required\n");
		exit (1);
	}

	if ((infile=fopen (argv[1],"rb"))==NULL)
	{
		printf ("Unable to open %s for read\n",argv[1]);
		exit (1);
	}


	while ((ch = fgetc (infile)) == 0);

	n = ch * 256;
	c = ch;
	biosprint (0,c,0);
	ch = fgetc (infile);
        n += ch;
	c = ch;
	biosprint (0,c,0);

	for (;n>0;n--){
		ch = fgetc (infile);
		c = ch;
/*
		printf ("%02X ",c);
*/
		biosprint (0,c,0);
	}


	fclose (infile);
}
